# link static:
#cc -DHAVE_CONFIG_H -I. -I../..  -I../../eibd/include -I../../common   -g -O2 -g -Wall -O2 -c eibread-cgi.c
#/bin/sh ../../libtool --tag=CC  --mode=link cc -all-static -static -g -O2 -g -Wall -O2   -o eibread-cgi eibread-cgi.o common.o ../client/c/libeibclient.la
#cc -g -O2 -g -Wall -O2 -o .libs/eibread-cgi eibread-cgi.o common.o  ../client/c/.libs/libeibclient.so

make

export QUERY_STRING='t=0&f=FILTER&a=100&a=5/2/79&a=1/5/61&a=&i=0'
export REQUEST_METHOD=GET

./eibread-cgi
