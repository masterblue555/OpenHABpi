#include <sys/types.h>
#include <sys/stat.h>

#include <errno.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#include <direct.h>

#define	mkdir(dir, perm)	_mkdir(dir)
#endif

#include "db.h"

/* Global environment and database handles for use by the application */
DB	*data_one;			/* Database handle */
DB	*data_two;			/* Database handle */

/* Public functions for use by the application */
int bdb_startup(void);
int bdb_shutdown(void);

/* DB_ENV initialization structures */
typedef struct {
	DB_ENV **envpp;
	char *home;
	u_int32_t gbytes;
	u_int32_t bytes;
	u_int32_t ncache;
	int private;
	int transaction;
} env_list_t;
static env_list_t env_list[] = {
 }
};

/* DB initialization structures */
typedef struct db_list_t {
	DB_ENV **envpp;
	DB **dbpp;
	char *name;
	DBTYPE type;
	u_int32_t extentsize;
	u_int32_t pagesize;
	u_int32_t re_len;
	int (*key_compare)(DB *, const DBT *, const DBT *);
	DB **primaryp;
	int (*secondary_callback)(DB *, const DBT *, const DBT *, DBT *);
	int dupsort;
	int recnum;
	int transaction;
} db_list_t;
static db_list_t db_list[] = {
	{ NULL, &data_one, "data_one", DB_BTREE, 0, 0, 0,
		NULL, NULL, NULL, 0, 0, 0 },
	{ NULL, &data_two, "data_two", DB_BTREE, 0, 0, 0,
		NULL, NULL, NULL, 0, 0, 0 }
};

#ifdef BUILD_STANDALONE
int
main()
{
	return (bdb_startup() && bdb_shutdown() ? EXIT_FAILURE : EXIT_SUCCESS);
}
#endif

static int bdb_env_startup(env_list_t *);
static int bdb_env_shutdown(env_list_t *);
static int bdb_db_startup(db_list_t *);
static int bdb_db_shutdown(db_list_t *);

/*
 * bdb_startup --
 *	Start up the environments and databases.
 */
int
bdb_startup()
{
	u_int i;

	/* Open environments. */
	for (i = 0; i < sizeof(env_list) / sizeof(env_list[0]); ++i)
		if (bdb_env_startup(&env_list[i]))
			return (1);
	/* Open primary databases. */
	for (i = 0; i < sizeof(db_list) / sizeof(db_list[0]); ++i)
		if (db_list[i].primaryp == NULL &&
		    bdb_db_startup(&db_list[i]))
			return (1);
	/* Open secondary databases. */
	for (i = 0; i < sizeof(db_list) / sizeof(db_list[0]); ++i)
		if (db_list[i].primaryp != NULL &&
		    bdb_db_startup(&db_list[i]))
			return (1);
	return (0);
}

/*
 * bdb_shutdown --
 *	Shut down the environments and databases.
 */
int
bdb_shutdown()
{
	u_int i;

	/* Close secondary databases. */
	for (i = 0; i < sizeof(db_list) / sizeof(db_list[0]); ++i)
		if (db_list[i].primaryp != NULL &&
		    bdb_db_shutdown(&db_list[i]))
			return (1);
	/* Close primary databases. */
	for (i = 0; i < sizeof(db_list) / sizeof(db_list[0]); ++i)
		if (db_list[i].primaryp == NULL &&
		    bdb_db_shutdown(&db_list[i]))
			return (1);
	/* Close environments. */
	for (i = 0; i < sizeof(env_list) / sizeof(env_list[0]); ++i)
		if (bdb_env_shutdown(&env_list[i]))
			return (1);
	return (0);
}

static int
bdb_env_startup(env_list_t *ep)
{
	struct stat sb;
	DB_ENV *dbenv;
	u_int32_t open_flags;
	int ret;

	/*
	 * If the directory doesn't exist, create it with permissions limited
	 * to the owner.  Assume errors caused by the directory not existing;
	 * we'd like to avoid interpreting system errors and it won't hurt to
	 * attempt to create an existing directory.
	 *
	 * !!!
	 * We use octal for the permissions, nothing else is portable.
	 */
	if (stat(ep->home, &sb) != 0)
		(void)mkdir(ep->home,  0700);

	/*
	 * If the environment is not transactional, remove and re-create it.
	 */
	if (!ep->transaction) {
		if ((ret = db_env_create(&dbenv, 0)) != 0) {
			fprintf(stderr, "db_env_create: %s", db_strerror(ret));
			return (1);
		}
		if ((ret = dbenv->remove(dbenv, ep->home, DB_FORCE)) != 0) {
			dbenv->err(dbenv, ret,
			    "DB_ENV->remove: %s", ep->home);
			goto err;
		}
	}

	/*
	 * Create the DB_ENV handle and initialize error reporting.
	 */
	if ((ret = db_env_create(&dbenv, 0)) != 0) {
		fprintf(stderr, "db_env_create: %s", db_strerror(ret));
		return (1);
	}
	dbenv->set_errpfx(dbenv, ep->home);
	dbenv->set_errfile(dbenv, stderr);

	 /* Configure the cache size. */
	if ((ep->gbytes != 0 || ep->bytes != 0) &&
	    (ret = dbenv->set_cachesize(dbenv,
	    ep->gbytes, ep->bytes, ep->ncache)) != 0) {
		dbenv->err(dbenv, ret, "DB_ENV->set_cachesize");
		goto err;
	}

	/*
	 * Open the environment.
	 */
	open_flags = DB_CREATE | DB_INIT_MPOOL | DB_THREAD;
	if (ep->private)
		open_flags |= DB_PRIVATE;
	if (ep->transaction)
		open_flags |= DB_INIT_LOCK |
		    DB_INIT_LOG | DB_INIT_TXN | DB_RECOVER;
	if ((ret = dbenv->open(dbenv, ep->home, open_flags, 0)) != 0) {
		dbenv->err(dbenv, ret, "DB_ENV->open: %s",  ep->home);
		goto err;
	}

	*ep->envpp = dbenv;
	return (0);

err:	(void)dbenv->close(dbenv, 0);
	return (1);
}

static int
bdb_db_startup(db_list_t *dp)
{
	DB_ENV *dbenv;
	DB *dbp;
	int ret;

	dbenv = dp->envpp == NULL ? NULL : *dp->envpp;

	/*
	 * If the database is not transactional, remove it and re-create it.
	 */
	if (!dp->transaction) {
		if ((ret = db_create(&dbp, dbenv, 0)) != 0) {
			if (dbenv == NULL)
				fprintf(stderr,
				    "db_create: %s\n", db_strerror(ret));
			else
				dbenv->err(dbenv, ret, "db_create");
			return (1);
		}
		if ((ret = dbp->remove(
		    dbp, dp->name, NULL, 0)) != 0 && ret != ENOENT) {
			if (dbenv == NULL)
				fprintf(stderr,
				    "DB->remove: %s: %s\n",
				    dp->name, db_strerror(ret));
			else
				dbenv->err(
				    dbenv, ret, "DB->remove: %s", dp->name);
			return (1);
		}
	}

	if ((ret = db_create(&dbp, dbenv, 0)) != 0) {
		if (dbenv == NULL)
			fprintf(stderr, "db_create: %s\n", db_strerror(ret));
		else
			dbenv->err(dbenv, ret, "db_create");
		return (1);
	}
	if (dbenv == NULL) {
		dbp->set_errpfx(dbp, dp->name);
		dbp->set_errfile(dbp, stderr);
	}

	if (dp->dupsort && (ret = dbp->set_flags(dbp, DB_DUPSORT)) != 0) {
		dbp->err(dbp, ret, "DB->set_flags: DB_DUPSORT: %s", dp->name);
		goto err;
	}

	if (dp->recnum && (ret = dbp->set_flags(dbp, DB_RECNUM)) != 0) {
		dbp->err(dbp, ret, "DB->set_flags: DB_RECNUM: %s", dp->name);
		goto err;
	}

	if (dp->extentsize != 0 &&
	    (ret = dbp->set_q_extentsize(dbp, dp->extentsize)) != 0) {
		dbp->err(dbp, ret,
		    "DB->set_q_extentsize: %lu: %s",
		    (u_long)dp->extentsize, dp->name);
		goto err;
	}

	if (dp->pagesize != 0 &&
	    (ret = dbp->set_pagesize(dbp, dp->pagesize)) != 0) {
		dbp->err(dbp, ret,
		    "DB->set_pagesize: %lu: %s",
		    (u_long)dp->pagesize, dp->name);
		goto err;
	}

	if (dp->re_len != 0 &&
	    (ret = dbp->set_re_len(dbp, dp->re_len)) != 0) {
		dbp->err(dbp, ret,
		    "DB->set_re_len: %lu: %s",
		    (u_long)dp->re_len, dp->name);
		goto err;
	}

	if (dp->key_compare != NULL &&
	    (ret = dbp->set_bt_compare(dbp, dp->key_compare)) != 0) {
		dbp->err(dbp, ret, "DB->set_bt_compare");
		goto err;
	}

	if ((ret = dbp->open(dbp, NULL, dp->name, NULL, dp->type,
	    (dp->transaction ? DB_AUTO_COMMIT : 0) |
	    DB_CREATE | DB_THREAD, 0)) != 0) {
		dbp->err(dbp, ret, "DB->open: %s", dp->name);
		goto err;
	}

	if (dp->primaryp != NULL &&
	    (ret = dbp->associate(*dp->primaryp,
	    NULL, dbp, dp->secondary_callback, DB_CREATE)) != 0) {
		dbp->err(dbp, ret, "DB->associate: %s", dp->name);
		goto err;
	}

	*dp->dbpp = dbp;
	return (0);

err:	(void)dbp->close(dbp, 0);
	return (1);
}

static int
bdb_env_shutdown(env_list_t *ep)
{
	DB_ENV *dbenv;
	int ret;

	dbenv = ep->envpp == NULL ? NULL : *ep->envpp;
	ret = 0;

	if (dbenv != NULL && (ret = dbenv->close(dbenv, 0)) != 0)
		fprintf(stderr,
		    "DB_ENV->close: %s: %s\n", ep->home, db_strerror(ret));
	return (ret == 0 ? 0 : 1);
}

static int
bdb_db_shutdown(db_list_t *dp)
{
	DB_ENV *dbenv;
	DB *dbp;
	int ret;

	dbenv = dp->envpp == NULL ? NULL : *dp->envpp;
	dbp = *dp->dbpp;
	ret = 0;

	/*
	 * If the database is transactionally protected, close without writing;
	 * dirty pages; otherwise, flush dirty pages to disk.
	 */
	if (dbp != NULL &&
	    (ret = dbp->close(dbp, dp->transaction ? DB_NOSYNC : 0)) != 0) {
		if (dbenv == NULL)
			fprintf(stderr,
			    "DB->close: %s: %s\n", dp->name, db_strerror(ret));
		else
			dbenv->err(dbenv, ret, "DB->close: %s", dp->name);
	}
	return (ret == 0 ? 0 : 1);
}
